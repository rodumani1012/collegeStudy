package com.example.music;

import android.content.Intent;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MusicActivity extends AppCompatActivity {

    MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);

        TextView titleTvId = findViewById(R.id.title);
        TextView composerTvId = findViewById(R.id.composer);
        ImageView imageView_image = findViewById(R.id.image);

        Intent it = getIntent();
        String tag = it.getStringExtra("tag");

        //태그 값에 해당하는 리소스를 가져와 화면에 출력한다
        Resources res =getResources();

        //앨범이미지
        //앨범 이미지명
        int imageId = res.getIdentifier("image" + tag, "string", getPackageName());
        String image = res.getString(imageId);
        //앨범이미지 리소스
        int imageDrawable = res.getIdentifier(image, "drawable", getPackageName());
        //앨범이미지 출력
        imageView_image.setImageResource(imageDrawable);

        //제목 갖고오기
        int titleId = res.getIdentifier("title" + tag, "string", getPackageName());
        String title = res.getString(titleId);

        titleTvId.setText(title);

        //가수명 갖고오기
        int composerId = res.getIdentifier("composer" + tag, "string", getPackageName());
        String composer = res.getString(composerId);

        composerTvId.setText(composer);

        //음악 갖고오기
        int audioId = res.getIdentifier("audio" + tag, "string", getPackageName());
        String audio = res.getString(audioId);

        //오디오 리소스
        int audioRaw = res.getIdentifier(audio, "raw", getPackageName());

        //미디어 플레이어 생성 및 재생
        mp = MediaPlayer.create(getApplicationContext(), audioRaw);
        mp.start();

    }

    public void goHome(View view) {
        //미디어 플레이어 종료
        if (mp != null) {
            mp.release();
        }
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        //미디어 플레이어 종료
        if (mp != null) {
            mp.release();
        }
    }
}
