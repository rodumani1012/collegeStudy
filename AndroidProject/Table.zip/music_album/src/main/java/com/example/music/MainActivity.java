package com.example.music;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void musicStart(View view) {

        int viewId = view.getId();
        ImageButton imgBtn = findViewById(viewId);

        String tag = (String) imgBtn.getTag();
        //Toast.makeText(this, "음악재생 tag = " + tag, Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(MainActivity.this, MusicActivity.class);
        intent.putExtra("tag", tag);
        startActivity(intent);
    }
}
