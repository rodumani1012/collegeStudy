package com.example.s405_12.imagepractice;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView iv_pinwheel = findViewById(R.id.imageView_pinwheel);

        ObjectAnimator object = ObjectAnimator.ofFloat(iv_pinwheel, "rotation", 360);
        //인식한 이미지를 360도 회전시키는 명령어
        object.setInterpolator(new LinearInterpolator());
        //일정한 속도로 움직이게 하는 것
        object.setDuration(2000);
        //애니메이션 1번 실행 소요시간 2초
        object.setRepeatCount(ValueAnimator.INFINITE);
        //얼만큼 돌것인가? 반복 횟수 지정
        object.start();
    }
}
