package com.example.movie_calendar;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import java.text.DecimalFormat;
import java.util.Calendar;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    TextView textViewDailyBoxOffice;
    EditText editTextDate; // 날짜 출력

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewDailyBoxOffice = (TextView) findViewById(R.id.textView_dailyboxoffcie);
        editTextDate = (EditText) findViewById(R.id.editText_date);
    }

    public void onClick_button_search(View view) {

        // 조회 날짜가 존재할 경우에만 조회한다.
        String searchDateText = editTextDate.getText().toString();

        if (searchDateText.length() == 10) {
            MyAsyncTask myAsyncTask = new MyAsyncTask();
            myAsyncTask.execute();
        } else {
            Toast.makeText(MainActivity.this, "날짜를 설정해 주세요.", Toast.LENGTH_SHORT).show();
        }

    }

    /*
    [ MyAsyncTask 클래스 정의 ]

    # AsyncTask<String, Void, MovieItem[]>

        Params : String. doInBackground 파라미터 타입. execute 메소드 인자 값
        Progress : Void. onProgressUpdate 파라미터 타입.
        Result :  MovieItem[]. onPostExecute 파라미터 타입. doInBackground 리턴값

     */
    public class MyAsyncTask extends AsyncTask<String, Void, MovieItem[]> {

        ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);

        // OkHttp 객체
        OkHttpClient client = new OkHttpClient();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.d("OpenAPI_Movie", "[MyAsyncTask.onPreExecute()::Start] -------------------------------------");


            // Show ProgressDialog
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setMessage("\tLoading...");
            progressDialog.show();

            Log.d("OpenAPI_Movie", "[MyAsyncTask.onPreExecute()::End] -------------------------------------");
        }

        @Override
        protected MovieItem[] doInBackground(String... params) {
            Log.d("OpenAPI_Movie", "[MyAsyncTask.doInBackground()::Start] -------------------------------------");


            // EditText로부터 조회 날짜를 얻어온다.
            // substring(a,b) : 문자열의 a번째 부터 b-1번째까지 문자을 얻어온다.
            String searchDateText = editTextDate.getText().toString();  // searchDateText 형식은 YYYY.MM.DD
            String searchDate = searchDateText.substring(0, 4) + searchDateText.substring(5, 7) + searchDateText.substring(8, 10);   // searchDate 형식은 YYYYMMDD
            Log.d("OpenAPI_Movie", "[MyAsyncTask.doInBackground()] searchDateText=[" + searchDateText + "]");
            Log.d("OpenAPI_Movie", "[MyAsyncTask.doInBackground()] searchDate=[" + searchDate + "]");


            HttpUrl.Builder urlBuilder = HttpUrl.parse("http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json").newBuilder();
            urlBuilder.addQueryParameter("key", "9b82a8003687cedb354dd25c5d71c5ab");
            urlBuilder.addQueryParameter("targetDt", searchDate);
            String url = urlBuilder.build().toString();

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            try {
                Response response = client.newCall(request).execute();

                // Gson을 이용하여 Json을 자바 객체로 변경한다.
                Gson gson = new GsonBuilder().create(); // Gson 객체 생성
                JsonParser parser = new JsonParser();   // 파서 생성

                JsonElement rootObject = parser.parse(response.body().charStream())
                        .getAsJsonObject().get("boxOfficeResult").getAsJsonObject().get("dailyBoxOfficeList"); //원하는 항목까지 찾아 들어가야 한다.
                MovieItem[] posts = gson.fromJson(rootObject, MovieItem[].class);

                return posts;

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                Log.d("OpenAPI_Movie", "[MyAsyncTask.doInBackground()::End] -------------------------------------");
            }

            return null;
        }

        @Override
        protected void onProgressUpdate(Void... params) {
            super.onProgressUpdate(params);
            Log.d("OpenAPI_Movie", "[MyAsyncTask.onProgressUpdate()::Start] -------------------------------------");
            Log.d("OpenAPI_Movie", "[MyAsyncTask.onProgressUpdate()::End] -------------------------------------");
        }

        @Override
        protected void onPostExecute(MovieItem[] param) {
            super.onPostExecute(param);
            Log.d("OpenAPI_Movie", "[MyAsyncTask.onPostExecute()::Start] -------------------------------------");

            // Terminate ProgressDialog
            progressDialog.dismiss();

            Log.d("OpenAPI_Movie", "[MyAsyncTask.onPostExecute()] param=[" + param + "] -------------------------------------");


            textViewDailyBoxOffice.setText(""); // TextView 초기화
            if (param.length > 0) {
                for (MovieItem post : param) {

                    int rank = post.getRank();
                    String movieNm = post.getMovieNm();
                    String OpenDt = post.getOpenDt();
                    long audiAcc = post.getAudiAcc();
                    long salesAcc = post.getSalesAcc();
                    String movieCd = post.getMovieCd();

                    String pattern = "###,###,###,###";
                    DecimalFormat decimalFormat = new DecimalFormat(pattern);
                    String audiAccWithComma = decimalFormat.format(audiAcc);
                    String salesAccWithComma = decimalFormat.format(salesAcc);

                    textViewDailyBoxOffice.append("순위 : " + rank + "\n");
                    textViewDailyBoxOffice.append("영화명 : " + movieNm + "\n");
                    textViewDailyBoxOffice.append("오픈일 : " + OpenDt + "\n");
                    textViewDailyBoxOffice.append("누적관객수 : " + audiAccWithComma + "\n");
                    textViewDailyBoxOffice.append("누적매출액 : " + salesAccWithComma + "\n");
                    textViewDailyBoxOffice.append("영화코드번호 : " + movieCd + "\n\n");

                    Log.d("OpenAPI_Movie", "[MyAsyncTask.onPostExecute()] rank=[" + rank + "] -------------------------------------");
                    Log.d("OpenAPI_Movie", "[MyAsyncTask.onPostExecute()] movieNm=[" + movieNm + "] -------------------------------------");
                    Log.d("OpenAPI_Movie", "[MyAsyncTask.onPostExecute()] OpenDt=[" + OpenDt + "] -------------------------------------");
                    Log.d("OpenAPI_Movie", "[MyAsyncTask.onPostExecute()] audiAcc=[" + audiAccWithComma + "] -------------------------------------");
                    Log.d("OpenAPI_Movie", "[MyAsyncTask.onPostExecute()] salesAcc=[" + salesAccWithComma + "] -------------------------------------");
                    Log.d("OpenAPI_Movie", "[MyAsyncTask.onPostExecute()] movieCd=[" + movieCd + "] -------------------------------------");
                }
            } else {
                textViewDailyBoxOffice.setText("조회 결과가 없습니다.");
            }

            Log.d("OpenAPI_Movie", "[MyAsyncTask.onPostExecute()::End] -------------------------------------");
        }

    }


    // DatePickerDialog 실행
    public void onClick_button_datepickerdialog(View view) {
        Toast.makeText(MainActivity.this, "DatePickerDailog", Toast.LENGTH_SHORT).show();

        // 현재 시간 가져오기
        Calendar today = Calendar.getInstance();
        int year = today.get(Calendar.YEAR);    // 현재 년도
        int month = today.get(Calendar.MONTH);  // 현재 월. 1월은 0
        int date = today.get(Calendar.DAY_OF_MONTH);    // 현재 월의 날짜.  Calendar.DATE 와 같다.
        int day = today.get(Calendar.DAY_OF_WEEK);  // 현재 요일(일요일 : 1, 토요일 : 7)
        int hour = today.get(Calendar.HOUR);    //현재 시간 (12시간제)
        int hourOfDay = today.get(Calendar.HOUR_OF_DAY);    //현재 시간 (24시간제)
        int minute = today.get(Calendar.MINUTE);    // 현재 분
        int second = today.get(Calendar.SECOND);    // 현재 초

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        int monthOfYearPlusOne = monthOfYear + 1;   // monthOfYear 은 0 ~ 11
                        String monthOfYearString = String.valueOf(monthOfYearPlusOne);
                        if (monthOfYearPlusOne < 10) {
                            monthOfYearString = "0" + monthOfYearPlusOne;
                        }

                        String dayOfMonthString = String.valueOf(dayOfMonth);
                        if (dayOfMonth < 10) {
                            dayOfMonthString = "0" + dayOfMonth;
                        }

                        editTextDate.setText(year + "." + monthOfYearString + "." + dayOfMonthString);

                    }
                }, year, month, date);
        datePickerDialog.show();
    }

}