package com.example.movie_calendar;

public class MovieItem {

    private int rank;           //  박스오피스 순위
    private String movieNm;     // 영화명
    private String openDt;      // 영화 오픈일
    private long audiAcc;        // 누적 관객수
    private long salesAcc;        // 누적 매출액
    private String movieCd;     // 영화코드. 영화 정보 검색 시 필요

    public int getRank() {
        return rank;
    }

    public String getMovieNm() {
        return movieNm;
    }

    public long getAudiAcc() {
        return audiAcc;
    }

    public String getOpenDt() {
        return openDt;
    }

    public String getMovieCd() {
        return movieCd;
    }

    public long getSalesAcc() {
        return salesAcc;
    }
}