package com.example.poeticalworks;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void displayPoem(View view) {

        //태그 값을 얻는다.
        int id = view.getId();
        LinearLayout layout = findViewById(id);
        String tag = (String) layout.getTag();

        //태그 값을 다른 액티비티로 전달한다.
        Intent intent = new Intent(MainActivity.this, PoemActivity.class);
        intent.putExtra("it_tag", tag); //tag 값(01,02...)을 "it_tag"라는 변수에 저장
        startActivity(intent);
    }
}
