package com.example.mediaplayer2;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    MediaPlayer mediaPlayer; //미디어 플레이어
    int audioId = R.raw.hare; //오디오 리소스

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //방식 2가지
        //1.   mediaPlayer = new MediaPlayer();
        //2.   mediaPlayer = MediaPlayer.create(MainActivity.this, audioId);
        mediaPlayer = MediaPlayer.create(MainActivity.this, audioId);
        //미디어 플레이어 재생
        mediaPlayer.start();
    }

    // 앱 종료시 자동으로 실행되는 함수
    @Override
    protected void onDestroy() {
        super.onDestroy();

        //미디어 플레이어의 자원을 해제한다.
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
    }
}
