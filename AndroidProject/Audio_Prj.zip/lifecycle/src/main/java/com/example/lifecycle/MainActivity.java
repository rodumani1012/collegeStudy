package com.example.lifecycle;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("LifeCycle", "onCreate()");

        textView = findViewById(R.id.text);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("LifeCycle", "onStart()");
        //초록
        textView.setBackgroundColor(Color.parseColor("#00FF00"));
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("LifeCycle", "onResume()");
        //노랑
        textView.setBackgroundColor(Color.parseColor("#FFFF00"));
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("LifeCycle", "onPause()");
        //주황
        textView.setBackgroundColor(Color.parseColor("#FFBF00"));

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("LifeCycle", "onDestroy()");
        //파랑
        textView.setBackgroundColor(Color.parseColor("#0000FF"));
    }
}
