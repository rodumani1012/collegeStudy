package com.example.a304_09.audio_prj;

import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/*
==================== [ MediaPlayer ] ====================
# 메소드
    start()             재생. 비동기식. 따라서 시작 후 다른 작업 가능
    pause()             일시정지
    strop()             종료
    release()           자원해제. 메모리에서 미디어 플레이어 객체 제거
    reset()             초기화되지 않은 처음 상태로 만든다.
    setLooping(true)    반복재생
    isPlaying()         재생 중 여부
                        true    : start()
                        false   : pause(), stop(), 음악이 끝까지 재생완료
 */
public class MainActivity extends AppCompatActivity {

    MediaPlayer mediaPlayer;    // 미디어 플레이어
    int audioId = R.raw.hare;  // 오디오 리소스

    // (추가) ------------------------------------------------------------------------------------
    Button btn_pause;           // 일시정지 버튼
    boolean pauseYn;            // 일시정지 여부.
    // true : 현재 일지정지 상태
    // false : 현재 일시정지 상태 아님
    //--------------------------------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 코딩 상 필요할 경우, 오디오 리소스가 없는 비어있는 미디어 플레이어를 먼저 생성하기도 한다.
        // 아래 코드가 없을 경우,
        // Stop 버튼을 start 버튼 보다 먼저 클릭하면, 에러가 발생한다.
        mediaPlayer = new MediaPlayer();

        // (추가) ---------------------------------------------------------------------------------
        btn_pause = findViewById(R.id.btn_pause);   // 일시정지 버튼
        pauseYn = false;    // 일시정지여부 초기화
        //----------------------------------------------------------------------------------------
    }

    // 미디어 플레이를 사용한다.
    public void audioPlayer(View view) {
        Toast.makeText(MainActivity.this, "audioPlayer()", Toast.LENGTH_SHORT).show();


        // 클릭한 버튼 아이디를 얻는다.
        int viewId = view.getId();

        switch (viewId) {

            case R.id.btn_play: // Play 버튼 클릭

                // (추가) ----------------------------------------------------------------------
                // 이전 미디어 플레이어를 리셋한다.
                // 아래 코드가 없을 경우, replay 기능이 계속 작동하여 음악이 중복되어 재생된다.
                mediaPlayer.reset();
                //------------------------------------------------------------------------------

                audioId = R.raw.hare;
                mediaPlayer = MediaPlayer.create(MainActivity.this, audioId);
                mediaPlayer.start();

                // (추가) ----------------------------------------------------------------------
                btn_pause.setText("Pause");
                btn_pause.setTextColor(Color.parseColor("#000000"));    // black
                pauseYn = false;
                //------------------------------------------------------------------------------

                break;
            case R.id.btn_stop: // Stop 버튼 클릭
                mediaPlayer.stop();

                // (추가) ----------------------------------------------------------------------
                btn_pause.setText("Pause");
                btn_pause.setTextColor(Color.parseColor("#000000"));    // black
                pauseYn = false;
                //------------------------------------------------------------------------------

                break;
            case R.id.btn_pause:    // Pause, Replay 버튼 클릭
                if (mediaPlayer.isPlaying()) {  // 재생중인 경우
                    mediaPlayer.pause();

                    // (추가) ----------------------------------------------------------------------
                    btn_pause.setText("RePlay");
                    btn_pause.setTextColor(Color.parseColor("#0000FF"));  // R.color.colorAccent 이런식으로 사용 불가
                    pauseYn = true;
                    //------------------------------------------------------------------------------

                }
                // (추가) ----------------------------------------------------------------------
                else {
                    if (pauseYn) {  // 일시정지인 경우
                        mediaPlayer.start();
                        btn_pause.setText("Pause");
                        btn_pause.setTextColor(Color.parseColor("#000000"));    // black
                        pauseYn = false;
                    }
                }
                //------------------------------------------------------------------------------

                break;
            default:
                mediaPlayer.stop();
                break;
        }

    }

    // 앱 종료시 자동 실행된다.
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 미디어 플레이어의 자원을 해제한다.
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
    }
    // (추가) --------------------------------------------------------------------------------------
    @Override
    protected void onPause() {  // 앱 일시정지
        super.onPause();
        // 미디어 플레이어의 자원을 해제한다.
        // 단, 다시 실행할 경우 미디어 플레이어 재설정이 필요하다.
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
    }
    @Override
    protected void onResume() { // 앱 시작 혹은 일시정지 후 재시작
        super.onResume();
        // 미디어 플레이어 준비한다.
        mediaPlayer = new MediaPlayer();
        btn_pause.setText("Pause");
        btn_pause.setTextColor(Color.parseColor("#000000"));    // black
        pauseYn = false;
    }
    //----------------------------------------------------------------------------------------------
}
