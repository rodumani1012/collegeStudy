package com.example.mediaplayer;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MediaPlayer mediaPlayer; //미디어 플레이어
        int audioId = R.raw.hare; //오디오 리소스

        //방식 2가지
        //1.   mediaPlayer = new MediaPlayer();
        //2.   mediaPlayer = MediaPlayer.create(MainActivity.this, audioId);
        mediaPlayer = MediaPlayer.create(MainActivity.this, audioId);
        //미디어 플레이어 재생
        mediaPlayer.start();
    }
}
