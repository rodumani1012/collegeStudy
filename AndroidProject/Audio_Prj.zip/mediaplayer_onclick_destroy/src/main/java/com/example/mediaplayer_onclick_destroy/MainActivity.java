package com.example.mediaplayer_onclick_destroy;

import android.graphics.Color;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    MediaPlayer mediaPlayer; //미디어 플레이어
    Button btn_pause; //일시정지 버튼

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //미디어 플레이어에 초기값을 셋팅해주는 것
        mediaPlayer = new MediaPlayer();
        btn_pause = findViewById(R.id.btn_pause);
    }

    public void player(View view) {

        //클릭한 버튼 아이디를 얻는다.
        int viewId = view.getId();

        switch (viewId) {
            case R.id.btn_play:
                mediaPlayer.reset(); //스택이 쌓이지않게 재생되고 있던 음악을 초기화한다.
                btn_pause.setText("Pause");
                btn_pause.setTextColor(Color.parseColor("#000000"));
                int audioId = R.raw.elephant;
                mediaPlayer = MediaPlayer.create(MainActivity.this, audioId);
                mediaPlayer.start();
                Toast.makeText(MainActivity.this, "재생합니다", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btn_pause:
                if (mediaPlayer.isPlaying()) {
                    Toast.makeText(MainActivity.this, "일시정지", Toast.LENGTH_SHORT).show();
                    mediaPlayer.pause();
                    btn_pause.setText("RePlay");
                    btn_pause.setTextColor(Color.parseColor("#0000FF"));
                } else {
                    mediaPlayer.start();
                    btn_pause.setText("Pause");
                    btn_pause.setTextColor(Color.parseColor("#000000"));
                }
                break;
            case R.id.btn_stop:
                btn_pause.setText("Pause");
                btn_pause.setTextColor(Color.parseColor("#000000"));
                mediaPlayer.stop();
                Toast.makeText(MainActivity.this, "정지합니다", Toast.LENGTH_SHORT).show();
                break;
            default:
                mediaPlayer.stop();
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
    }

    @Override
    protected void onPause() { //바탕화면 등 외부로 나갔을 때 음악 정지
        super.onPause();
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }

    }

    @Override
    protected void onResume() { //앱 시작 혹은 일시정지 후 재시작
        super.onResume();
        //미디어 플레이어를 준비한다
        mediaPlayer = new MediaPlayer();
        btn_pause.setText("Pause");
        btn_pause.setTextColor(Color.parseColor("#000000"));
    }
}