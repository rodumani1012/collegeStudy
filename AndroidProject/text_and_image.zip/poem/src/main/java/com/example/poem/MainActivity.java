package com.example.poem;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //흐르는 글자
        TextView body01 = findViewById(R.id.body01);
        body01.setSelected(true);

        TextView body02 = findViewById(R.id.body02);
        body02.setSelected(true);

    }
}
