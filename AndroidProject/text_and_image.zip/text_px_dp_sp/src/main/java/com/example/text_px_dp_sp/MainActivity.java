package com.example.text_px_dp_sp;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //객체 접근
        TextView tv4 = findViewById(R.id.textView4);

        // 다른 글자 설정
        tv4.setText("World");   //셋팅
        tv4.append("!!!");      // 컨텐츠 추가

        //색상 변경
        tv4.setTextColor(Color.RED);
        //tv4.setTextColor(Color.parseColor("#0000FF"));

        //글자크기 변경
        tv4.setTextSize(TypedValue.COMPLEX_UNIT_SP, 40);
        //tv4.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 40);

        //기타
        tv4.setTypeface(null, Typeface.BOLD); //글자 굵게
        tv4.setGravity(Gravity.CENTER); //컨텐츠 위치
    }
}
