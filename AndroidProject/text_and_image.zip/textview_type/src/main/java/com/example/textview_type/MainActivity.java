package com.example.textview_type;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Marquee 적용
        TextView tv5 = findViewById(R.id.textView5);
        tv5.setSelected(true);
    }
}
