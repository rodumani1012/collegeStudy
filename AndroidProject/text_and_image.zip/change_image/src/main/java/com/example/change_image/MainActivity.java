package com.example.change_image;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //이미지 변경
    // setImageResource() 사용
    public void changeImage(View view) {

        int imageViewId = R.id.imageView;
        int imageId = R.drawable.beer;

        ImageView imageView = findViewById(imageViewId);
        imageView.setImageResource(imageId);
    }

    // 이미지 변경 토글
    // 첫번째 이미지 사용 여부
    private boolean firstImageUseYn = true;
    public void changeImageToggle(View view) {
        int imageViewId = R.id.imageView;
        int firstImageId = R.drawable.ma;
        int secondImageId = R.drawable.beer;

        ImageView imageView = findViewById(imageViewId);

        if (firstImageUseYn) {
            imageView.setImageResource(secondImageId);
            firstImageUseYn = false;
        } else {
            imageView.setImageResource(firstImageId);
            firstImageUseYn = true;
        }
    }
}
