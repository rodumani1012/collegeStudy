package com.example.resource_color;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 안드로이드 API 버전
        int version = Build.VERSION.SDK_INT;

        // 색상 정보
        int color; // 변경할 색상
        int colorId = R.color.colorAccent; // 변경할 색상 아이디

        // 텍스트뷰 정보
        int textViewId = R.id.textView1;
        TextView textView = findViewById(textViewId);

        // 텍스트뷰의 색상 변경
        if (version >= 23) {
            color = ContextCompat.getColor(this, colorId);
            textView.setTextColor(color);
        } else {
            color = getResources().getColor(colorId);
            textView.setTextColor(color);
        }
    }
}
