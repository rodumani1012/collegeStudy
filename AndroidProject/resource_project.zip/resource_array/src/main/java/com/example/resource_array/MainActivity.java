package com.example.resource_array;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //문자열 배열을 화면에 출력한다.
    public void printStringArray(View view) {

        // 배열 소스
        int arrayId = R.array.stringArraySports;

        // 배열 추출
        String[] stringArraySports = getResources().getStringArray(arrayId);

        // 뷰 생성
        TextView t1 = findViewById(R.id.textView1);
        TextView t2 = findViewById(R.id.textView2);
        TextView t3 = findViewById(R.id.textView3);

        // 배열 출력 : 문자
        t1.setText(stringArraySports[0]);
        t2.setText(stringArraySports[1]);
        t3.setText(stringArraySports[2]);
    }

    public void printIntArray(View view) {

        int arrayId = R.array.intArrayAges;

        int[]  intArrayAges = getResources().getIntArray(arrayId);

        TextView t1 = findViewById(R.id.textView1);
        TextView t2 = findViewById(R.id.textView2);
        TextView t3 = findViewById(R.id.textView3);

        t1.setText(Integer.toString(intArrayAges[0]));
        t2.setText(Integer.toString(intArrayAges[1]));
        t3.setText(Integer.toString(intArrayAges[2]));
    }
}
