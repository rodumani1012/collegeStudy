package com.example.resource_color_changecolor;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    // 글자색 변경
    public void changeTextColor(View view) {

        //안드로이드 API 버전 가져오기
        int version = Build.VERSION.SDK_INT;

        //색상 리소스 가져오기
        int color;
        int colorId = R.color.colorAccent;

        //Text View 가져오기
        int textViewId = R.id.textView;
        TextView textView = findViewById(R.id.textView);

        if (version >= 23) {
            color = ContextCompat.getColor(this, colorId);
            textView.setTextColor(color);
        } else {
            color = getResources().getColor(colorId);
            textView.setTextColor(color);
        }
    }

    public void changeBackground(View view) {

        //안드로이드 API 버전 가져오기
        int version = Build.VERSION.SDK_INT;

        //색상 리소스 가져오기
        int color;
        int colorId = R.color.colorYellow;


        //Text View 가져오기
        int textViewId = R.id.textView;
        TextView textView = findViewById(R.id.textView);

        if (version >= 23) {
            color = ContextCompat.getColor(this, colorId);
            textView.setBackgroundColor(color);
        } else {
            color = getResources().getColor(colorId);
            textView.setBackgroundColor(color);
        }
    }
}
