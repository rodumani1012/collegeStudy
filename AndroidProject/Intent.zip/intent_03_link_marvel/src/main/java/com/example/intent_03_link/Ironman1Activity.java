package com.example.intent_03_link;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class Ironman1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ironman1);

        TextView textView = findViewById(R.id.ironman1Tv);
        textView.setSelected(true);
    }

    public void backHome(View view) {
        finish();
    }
}
