package com.example.intent_03_link;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void ironman1(View view) {
        Intent intent = new Intent(MainActivity.this, Ironman1Activity.class);
        startActivity(intent);
    }

    public void hulk1(View view) {
        Intent intent = new Intent(MainActivity.this, Hulk1Activity.class);
        startActivity(intent);
    }

    public void ironman2(View view) {
        Intent intent = new Intent(MainActivity.this, Ironman2Activity.class);
        startActivity(intent);
    }

    public void thor1(View view) {
        Intent intent = new Intent(MainActivity.this, ThorActivity.class);
        startActivity(intent);
    }

    public void captin1(View view) {
        Intent intent = new Intent(MainActivity.this, Captin1Activity.class);
        startActivity(intent);
    }
}
