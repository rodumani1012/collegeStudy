package com.example.intent1;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void doDial(View view) {
        String data = "tel:01012345678";

        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(data)); //data를 가져와서 ACTION_DIAL 함
        startActivity(intent);
    }

    public void doBrowser(View view) {
        String data =  "http://www.google.com";
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(data));
        startActivity(intent);
    }

    public void doMap(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        String latitude = "37.380439"; //위도
        String longitude = "123.927497"; // 경도
        intent.setData(Uri.parse("geo:" + latitude + ", " + longitude));
        startActivity(intent);
    }

    public void doDiallist(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        String data = "//contacts/people/";
        intent.setData(Uri.parse("content:" + data));
        startActivity(intent);
    }

    public void doCamera(View view) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivity(intent);
    }

    public void doVibrator(View view) {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(1000);
    }
}
