package com.example.intent_02_subactivity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
    }

    //서브 액티비티를 종료한다.
    public void finishSubActivity(View view) {
        // 서브 액티비티 종료
        finish();
    }


    //서브 액티비티를 종료하고 결과를 전송한다.
    public void finishSubActivityResult(View view) {

        // 결과 처리 방법 1 --------------------------------------------------------
        // 코드만 전송 하는 경우
        setResult(900);


        // 결과 처리 방법 2 --------------------------------------------------------
        // 결과코드와 데이터를 전송하는 경우
//        Intent intent = new Intent();
//        intent.putExtra("resultMessage", "완료");
//        setResult(100, intent);


        // 서브 액티비티 종료
        finish();
    }
}
