package com.example.intent_02_subactivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //서브 액티비티를 실행한다.
    public void beginSubActivity(View view) {

        //인텐트 설정
        Intent intent = new Intent(MainActivity.this, SubActivity.class);
        //인텐트 실행
        startActivity(intent);
    }


    //서브 액티비티를 실행하고 결과를 요청한다.
    public void beginSubActivityResult(View view) {

        //인텐트 설정
        Intent intent = new Intent(MainActivity.this, SubActivity.class);

        // 인텐트 실행
        startActivityForResult(intent, 100);

    }

    //서브 액티비티로부터 결과를 얻는다.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // 결과 처리 방법 1 --------------------------------------------------------
        // 서브 액티비티가 결과 코드만 전송한 경우
        Toast.makeText(this, "onActivityResult()::요청코드=[" + requestCode + "] 응답코드=[" + resultCode + "]", Toast.LENGTH_SHORT).show();


        // 결과 처리 방법 2 --------------------------------------------------------
        // 서브 액티비티가 결과 코드와 메시지를 같이 전송한 경우
//        String resultMessage = data.getStringExtra("resultMessage");
//        Toast.makeText(this, "onActivityResult()::요청코드=[" + requestCode + "] 응답코드=[" + resultCode + "] 전송자료=[" + resultMessage + "]" , Toast.LENGTH_SHORT).show();

    }
}
