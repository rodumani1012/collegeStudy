package test.school;

public class Staff implements Person {
	public void printName() {
		System.out.println("�����̸�");
	}
}
