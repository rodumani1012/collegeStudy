package class30_api.ep04_decimalformat;

import java.text.DecimalFormat;

public class MainDecimal {

	public static void main(String[] args) {
		
//		 [ DecimalFormat ]
//			10진수의 값을 원하는 포멧으로 변형해 주는 클래스 
//			format 메소드를 사용해서 특정 패턴으로 값을 포맷	
//		 	패턴 형식은 '0'과 '#'을 사용 해서 지정
//		 	'0' 은 표시한 자리수만큼의 값을 최소한으로 표시
//		  	#은 표시한 소수점자리수만큼 반올림하여 표시 
//		
//		[ 패턴 ] 
//			# : 10진수 
//			. : 소수점
		 

		// 정수 : 3자리마다 코마를 찍는다. 
		System.out.println("---------- 정수 ----------");
		
		// 포멧 1
		DecimalFormat df1 = new DecimalFormat("#,###");
		
		int intValue = 1000000; // 원본		
		String result1 = df1.format(intValue); // 결과
		System.out.println("원본=" + intValue + " 결과=" + result1);

		// 포멧 2
		long longValue = 500000000L; // 원본
		String result2 = df1.format(longValue); // 결과
		System.out.println("원본=" + longValue + " 결과=" + result2);

		
		// 소수점
		System.out.println("---------- 소수점 ----------");
		
		float floatValue = 1000.235F; // 원본		
		
		// 포멧 1
		DecimalFormat df5 = new DecimalFormat("#.#");
		String result5 = df5.format(floatValue); // 결과
		System.out.println("원본=" + floatValue + " 결과=" + result5);

		// 포멧 2
		DecimalFormat df6 = new DecimalFormat("#.##");
		String result6 = df6.format(floatValue); // 결과
		System.out.println("원본=" + floatValue + " 결과=" + result6);

		// 포멧 3
		DecimalFormat df7 = new DecimalFormat("#.###");
		String result7 = df7.format(floatValue); // 결과
		System.out.println("원본=" + floatValue + " 결과=" + result7);
	}

}
