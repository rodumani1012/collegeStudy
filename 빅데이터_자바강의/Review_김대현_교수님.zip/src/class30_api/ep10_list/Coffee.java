package class30_api.ep10_list;

public class Coffee {

	// Variable
	private String name; // 커피명
	private int price; // 가격
	
	// Constructor
	public Coffee(String name, int price) {
		super();
		this.name = name;
		this.price = price;
	}

	// Method	
	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void printInfo() {
		System.out.print("이름=[" + name + "] ");
		System.out.println("가격=[" + price + "]");
	}

}