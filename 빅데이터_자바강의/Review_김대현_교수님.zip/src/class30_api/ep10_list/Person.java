package class30_api.ep10_list;

public class Person {

	// Variable
	private String name; // 이름
	private int age; // 나이

	// Constructor
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	// Method
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void printInfo() {
		System.out.print("name=[" + name + "] ");
		System.out.println(" age=[" + age + "]");
	}

}
