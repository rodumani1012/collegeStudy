package class30_api.ep10_list;

import java.util.ArrayList;
import java.util.List;

public class MainArrayList_03_Coffee {

	public static void main(String[] args) {

		// 선언 및 생성
		List<Coffee> coffeeList = new ArrayList<Coffee>(); // Generic
		
		// isEmpty(), size()
		System.out.print("empty=[" + coffeeList.isEmpty() + "]");
		System.out.println(" size=[" + coffeeList.size() + "]");

		// Add
//		Coffee c1 = new Coffee("아메리카노", 1000);
//		Coffee c2 = new Coffee("라떼", 2000);
//		coffeeList.add(c1);
//		coffeeList.add(c2);
//
//		for (int i = 0; i < coffeeList.size(); i++) {
//
//			Coffee c = coffeeList.get(i);
//			c.printInfo();
//
//		}

	}
}
