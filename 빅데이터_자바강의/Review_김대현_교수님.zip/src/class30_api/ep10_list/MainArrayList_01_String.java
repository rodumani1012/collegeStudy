package class30_api.ep10_list;

import java.util.ArrayList;

public class MainArrayList_01_String {

	public static void main(String[] args) {

		// 선언 및 생성
		ArrayList<String> list = new ArrayList<String>();
		
		// isEmpty(), size()
		System.out.print("empty=[" + list.isEmpty() + "]");
		System.out.println(" size=[" + list.size() + "]");

		// Add
//		list.add("월");
//		list.add("화");
//		list.add("수");
//		list.add("목");
//		list.add("금");
//
//		for (int i = 0; i < list.size(); i++) {
//			String s = list.get(i);
//			System.out.println("list[" + i + "]=[" + s + "]");
//		}		

	}

}
