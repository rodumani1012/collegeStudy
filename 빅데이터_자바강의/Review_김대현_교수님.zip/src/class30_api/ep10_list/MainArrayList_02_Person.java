package class30_api.ep10_list;

import java.util.ArrayList;
import java.util.List;

public class MainArrayList_02_Person {

	public static void main(String[] args) {

		// 선언 및 생성
		List<Person> personList = new ArrayList<Person>(); // Generic
		
		// isEmpty(), size()
		System.out.print("empty=[" + personList.isEmpty() + "]");
		System.out.println(" size=[" + personList.size() + "]");

		// Add
//		Person p1 = new Person("Kim", 20);
//		Person p2 = new Person("Lee", 22);
//		personList.add(p1);
//		personList.add(p2);
//
//		for (int i = 0; i < personList.size(); i++) {
//
//			Person p = personList.get(i);
//			p.printInfo();
//
//		}

	}
}
