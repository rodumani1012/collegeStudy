package class30_api.ep01_string;

public class ep10_MainStringMethod {

	public static void main(String[] args) {

		// Method 1
		String str1 = "Hello World !!!";
		System.out.println("str1=[" + str1 + "]");

		// length()
		// System.out.println("str1.length()=[" + str1.length() + "]");

		// charAt(index)
		// System.out.println("str1.charAt(1)=[" + str1.charAt(1) + "]");

		// substring(index1, index2)
		// target : index1 ~ (index2-1)
		// System.out.println("str1.substring(0,2)=[" + str1.substring(0, 2) +
		// "]");

		// Method 2
		// String str2 = " Good Morning ";
		// System.out.println("\nstr2=[" + str2 + "]");

		// trim()
		// String 앞,뒤 space 제거
		// System.out.println("str2.trim()=[" + str2.trim() + "]");

		// Method 3
		// String str3 = "Water";
		// String str4 = "WATER";

		// equals() : 대소문자 구분하여 비교
		// if (str3.equals(str4)) {
		// System.out.println("str3.equals(str4)=[true]");
		// } else {
		// System.out.println("str3.equals(str4)=[false]");
		// }

		// equalsIgnoreCase() : 대소문자 구분하지 않고 비교
		// if (str3.equalsIgnoreCase(str4)) {
		// System.out.println("str3.equalsIgnoreCase(str4)=[true]");
		// } else {
		// System.out.println("str3.equalsIgnoreCase(str4)=[false]");
		// }

	}

}