package class30_api.ep01_string;

public class ep02_MainStringEquals {

	public static void main(String[] args) {

		// int
		int intVal1 = 10;
		int intVal2 = 10;
		System.out.println("---------- int ----------");
		System.out.println(intVal1 == intVal2);

		// String
		String s1 = "hello";
		String s2 = new String("hello");

		System.out.println("\n---------- String ----------");
		System.out.println(s1 == s2);

		// String : equals() ----------------------------------------
		System.out.println("\n---------- String : equals() ----------");
		System.out.println(s1.equals(s2));
	}

}
