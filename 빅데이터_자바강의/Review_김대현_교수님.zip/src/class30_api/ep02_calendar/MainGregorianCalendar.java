package class30_api.ep02_calendar;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class MainGregorianCalendar {

	public static void main(String[] args) {

		// Calendar c = new GregorianCalendar();
		GregorianCalendar c = new GregorianCalendar(); // 시스템 시간을 얻는다.

		int yearInt = c.get(Calendar.YEAR);
		int monthInt = c.get(Calendar.MONTH); // 0 ~ 11.
		int dateInt = c.get(Calendar.DATE);
		int hourInt = c.get(Calendar.HOUR_OF_DAY);
		int minuteInt = c.get(Calendar.MINUTE);
		int secondInt = c.get(Calendar.SECOND);

		System.out.println("년=[" + yearInt + "]");
		System.out.println("월=[" + (monthInt + 1) + "]");
		System.out.println("일=[" + dateInt + "]");
		System.out.println("시=[" + hourInt + "]");
		System.out.println("분=[" + minuteInt + "]");
		System.out.println("초=[" + secondInt + "]");
		System.out.println("");

		// Add "0 " example) 5 --> 05
		if (monthInt < 10) {
			System.out.println("월=[" + "0" + monthInt + "]");
		}

	}

}
