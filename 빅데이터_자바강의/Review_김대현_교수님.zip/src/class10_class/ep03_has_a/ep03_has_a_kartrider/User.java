package class10_class.ep03_has_a.ep03_has_a_kartrider;

public class User {

	// Variable
	private String id; // 아이디
	private String name; // 이름
	private String grade; // 등급. D:Diamond G:Gold, S:Silver, B:Bronze, C:Common
							// People(평민)
	private int lucci; // 루찌
	private Kart kart; // 카트

	// Constructor
	public User() {

	}

	public User(String id, String name, Kart kart) {
		this.id = id;
		this.name = name;
		this.grade = "C";
		this.lucci = 0;
		this.kart = kart;
	}

	public User(String id, String name, String grade, int lucci, Kart kart) {
		this.id = id;
		this.name = name;
		this.grade = grade;
		this.lucci = lucci;
		this.kart = kart;
	}

	// Method
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public int getLucci() {
		return lucci;
	}

	public void setLucci(int lucci) {
		this.lucci = lucci;
	}

	public Kart getKart() {
		return kart;
	}

	public void setKart(Kart kart) {
		this.kart = kart;
	}

	public void printInfo() {
		System.out.println("\tUser Information -----------------");
		System.out.print("\t\tid:" + id);
		System.out.print(" / name:" + name);
		System.out.print(" / grade:" + grade);
		System.out.println(" / lucci:" + lucci);
		kart.printInfo();
	}

	public void go() {
		String kartName = kart.getName();
		System.out.println("\n[" + id + "] " + kartName + " go()");
		printInfo();
	}

	public void stop() {
		String kartName = kart.getName();
		System.out.println("\n[" + id + "] " + kartName + " stop()");
		printInfo();
	}

	public void getLucci100() {
		String kartName = kart.getName();
		System.out.println("\n[" + id + "] " + kartName + " getLucci100()");
		lucci = lucci + 100;
		printInfo();
	}

}
