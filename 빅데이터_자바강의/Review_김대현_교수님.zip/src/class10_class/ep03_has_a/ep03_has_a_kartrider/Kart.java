package class10_class.ep03_has_a.ep03_has_a_kartrider;

public class Kart {

	// Variable
	private String name; // 이름. 세이버,솔리드,버스트,코튼,몬스터
	private String color; // 색깔
	private int speed; // 현재속도. 최대 100
	private int booster; // 부스터. 최대 2개.

	// Constructor
	public Kart() {

	}

	public Kart(String name, String color) {
		this.name = name;
		this.color = color;
		this.speed = 0;
		this.booster = 0;
	}

	public Kart(String name, String color, int speed, int booster) {
		this.name = name;
		this.color = color;
		this.speed = speed;
		this.booster = booster;
	}

	// Method
	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public int getBooster() {
		return booster;
	}

	public void setBooster(int booster) {
		this.booster = booster;
	}

	// Method
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void printInfo() {
		System.out.println("\tKart Information -----------------");
		System.out.print("\t\tname:" + name);
		System.out.print(" / color:" + color);
		System.out.print(" / speed:" + speed);
		System.out.println(" / booster:" + booster);
	}

}
