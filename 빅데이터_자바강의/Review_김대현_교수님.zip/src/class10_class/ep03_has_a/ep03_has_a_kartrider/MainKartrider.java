package class10_class.ep03_has_a.ep03_has_a_kartrider;

public class MainKartrider {

	public static void main(String[] args) {

		// Object 1
		Kart k1 = new Kart("몬스터", "Green", 90, 2);
		User u1 = new User("BlueSky", "Bong", "C", 0, k1);
		u1.printInfo();
//		 u1.go();
//		 u1.stop();
//		 u1.getLucci100();

		// Object 2
		// Kart k2 = new Kart("세이버", "White", 100, 1);
		// User u2 = new User("BlueSky", "Bong", "C", 0, k1);
		// u2.printInfo();
		// u2.go();
		// u2.stop();
	}

}
