package class10_class.ep03_has_a.ep02_has_a_song;

public class MainSong {

	public static void main(String[] args) {

		Singer singer1 = new Singer("아이유", 'F', "19930516", "로엔엔터테인먼트");
		Song song1 = new Song("밤편지", singer1, "밤편지", "김제회,김희원", "아이유", "20170324");
		song1.printInfo();

	}

}
