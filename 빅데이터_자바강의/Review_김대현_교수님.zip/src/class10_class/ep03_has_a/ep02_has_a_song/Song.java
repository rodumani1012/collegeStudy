package class10_class.ep03_has_a.ep02_has_a_song;

public class Song {

	// Variable
	private String title;
	private Singer singer; // 가수
	private String album; // 앨범
	private String composer; // 작곡가
	private String lyricist; // 작사가
	private String releaseDate; // 발매일(YYYYMMDD)

	// Constructor
	public Song(String title, Singer singer, String album, String composer, String lyricist, String releaseDate) {
		this.title = title;
		this.album = album;
		this.singer = singer;
		this.composer = composer;
		this.lyricist = lyricist;
		this.releaseDate = releaseDate;
	}

	// Method
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Singer getSinger() {
		return singer;
	}

	public void setSinger(Singer singer) {
		this.singer = singer;
	}

	public String getComposer() {
		return composer;
	}

	public void setComposer(String composer) {
		this.composer = composer;
	}

	public String getLyricist() {
		return lyricist;
	}

	public void setLyricist(String lyricist) {
		this.lyricist = lyricist;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public void printInfo() {
		System.out.println("Song Information ----------------------------------------");
		System.out.print("title=[" + title + "]");
		System.out.print(" album=[" + album + "]");
		System.out.print(" composer=[" + composer + "]");
		System.out.print(" lyricist=[" + lyricist + "]");
		System.out.println(" releaseDate=[" + releaseDate + "]");
		singer.printInfo();
	}

}
