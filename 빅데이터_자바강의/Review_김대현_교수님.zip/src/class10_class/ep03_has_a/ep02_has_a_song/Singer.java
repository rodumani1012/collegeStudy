package class10_class.ep03_has_a.ep02_has_a_song;

public class Singer {

	// Variable
	private String name; // 이름
	private char sex; // 성별. F(female) 여성, M(male) 남성
	private String birthDate; // 생년월일. 형식 : YYYYMMDD
	private String company; // 소속사

	// Constructor
	public Singer(String name, char sex, String birthDate, String company) {
		this.name = name;
		this.sex = sex;
		this.birthDate = birthDate;
		this.company = company;
	}

	// Method
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public char getSex() {
		return sex;
	}

	public void setSex(char sex) {
		this.sex = sex;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public void printInfo() {
		System.out.println("\t* Singer Information");
		System.out.print("\tname=[" + name + "]");
		System.out.print(" sex=[" + sex + "]");
		System.out.print(" birthDate=[" + birthDate + "]");
		System.out.print(" println=[" + company + "]");
	}

}
