package class20_array.ep02_intializer;

public class MainArrayInitializerString {

	public static void main(String[] args) {

		String[] arrayStr1 = new String[2]; // 선언 및 생성

		arrayStr1[0] = "Hello";
		arrayStr1[1] = "Java";

		for (int i = 0; i < arrayStr1.length; i++) {
			System.out.print("arrayStr1[" + i + "] ");
			System.out.println(arrayStr1[i]);
		}

		// Array Initializer ------------------------------------------
		String arrayStr2[] = { "Hello", "Java" };

		System.out.println();
		for (int i = 0; i < arrayStr2.length; i++) {
			System.out.print("arrayStr2[" + i + "] ");
			System.out.println(arrayStr2[i]);
		}

	}

}
