package class20_array.ep02_intializer;

public class MainArrayInitializerInt {

	public static void main(String[] args) {

		int[] intArray1 = new int[2]; // 선언 및 생성

		intArray1[0] = 10;
		intArray1[1] = 20;

		for (int i = 0; i < intArray1.length; i++) {
			System.out.print("intArray1[" + i + "] ");
			System.out.println(intArray1[i]);
		}

		// Array Initializer -----------------------------------
		int intArray2[] = { 10, 20 };

		System.out.println();
		for (int i = 0; i < intArray2.length; i++) {
			System.out.print("intArray2[" + i + "] ");
			System.out.println(intArray2[i]);
		}

	}

}
