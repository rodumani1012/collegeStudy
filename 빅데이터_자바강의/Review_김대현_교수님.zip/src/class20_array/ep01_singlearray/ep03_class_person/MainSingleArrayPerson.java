package class20_array.ep01_singlearray.ep03_class_person;

public class MainSingleArrayPerson {

	public static void main(String[] args) {

		// Declaration
		Person[] personArray;

		// Creation
		personArray = new Person[3];

		// Initialization : Type1
		personArray[0] = new Person();
		personArray[0].setName("Hong");
		personArray[0].setAge(25);

		// Initialization : Type2
		personArray[1] = new Person("Lee", 40);

		// Initialization : Type3
		Person p = new Person("Park", 35);
		personArray[2] = p;

		// Output
		// personArray[0].printInfo();
		// personArray[1].printInfo();
		// personArray[2].printInfo();

		// Output : length
		// int arrayLength = personArray.length;
		// System.out.println("arrayLength=[" + arrayLength + "]");
		//
		// for (int i = 0; i < personArray.length; i++) {
		// System.out.print("personArray[" + i + "] ");
		// personArray[i].printInfo();
		// }

	}

}
