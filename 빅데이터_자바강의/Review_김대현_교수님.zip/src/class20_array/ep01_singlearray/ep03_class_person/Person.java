package class20_array.ep01_singlearray.ep03_class_person;

public class Person {

	// Variable
	private String name;
	private int age;

	// Constructor
	public Person() {

	}

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	// Method
	public void setName(String newName) {
		name = newName;
	}

	public String getName() {
		return name;
	}

	public void setAge(int newAge) {
		age = newAge;
	}

	public int getAge() {
		return age;
	}

	public void printInfo() {
		System.out.print("name=[" + name + "]");
		System.out.println(" age=[" + age + "]");
	}

}
