package class20_array.ep01_singlearray.ep02_string;

public class MainWeekDay {

	public static void main(String[] args) {
		
		String [] weekDay = new String[7];
		weekDay[0] = "월";
		weekDay[1] = "화";
		weekDay[2] = "수";
		weekDay[3] = "목";
		weekDay[4] = "금";
		weekDay[5] = "토";
		weekDay[6] = "일";
		
		System.out.println("Week Day -----------------------------------");
		for(int i=0;i<weekDay.length;i++) {
			String day = weekDay[i] + "요일";
			System.out.println(day);
		}

	}

}
