package class20_array.ep01_singlearray.ep02_string;

public class MainSingleArrayString {

	public static void main(String[] args) {

		// Declaration
		String[] stringArray;

		// Creation
		stringArray = new String[3];

		// Initialization
		stringArray[0] = new String("Hello");
		stringArray[1] = new String("Java");
		stringArray[2] = new String("Brain");

		// Output
		System.out.println(stringArray[0]);
		System.out.println(stringArray[1]);
		System.out.println(stringArray[2]);

		// Output : length
		// int arrayLength = stringArray.length;
		// System.out.println("arrayLength=[" + arrayLength + "]");
		//
		// for (int i = 0; i < stringArray.length; i++) {
		// System.out.print("stringArray[" + i + "] ");
		// System.out.println(stringArray[i]);
		// }
	}

}
