package class20_array.ep04_lotto;

public class MainLotto {

	public static void main(String[] args) {


		// Lotto & Array
		// Array
		int[] lotto = new int[6];

		// Initialization
		for (int i = 0; i < lotto.length; i++) {
			double random = Math.random();		
			int randomInt = (int) (random * 100);
			lotto[i] = randomInt;
		}

		System.out.println("Lotto ----------------------------------------------");
		for (int i = 0; i < lotto.length; i++) {
			System.out.print("\t" + lotto[i]);
		}

	}

}
