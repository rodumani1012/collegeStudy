package class20_array.ep03_classdesign.ep01_movie;

public class MainMovie {

	public static void main(String[] args) {

		// Object
		Movie m1 = new Movie("Starwars:깨어난포스", "SF", "J.J.에이브럼스", 135);
		m1.printInfo();

		Movie m2 = new Movie("007 스펙터", "액션", "샘 멘데스", 148);
		m2.printInfo();

		// Array
		// Movie[] movieArray; // 배열 선언
		//
		// movieArray = new Movie[2]; // 배열 생성
		// movieArray[0] = new Movie("Starwars:깨어난포스", "SF", "J.J.에이브럼스", 135);
		// movieArray[1] = new Movie("007 스펙터", "액션", "샘 멘데스", 148);
		//
		// for (int i = 0; i < movieArray.length; i++) {
		// movieArray[i].printInfo();
		// }
	}

}
