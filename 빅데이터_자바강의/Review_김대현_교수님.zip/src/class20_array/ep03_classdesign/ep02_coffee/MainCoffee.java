package class20_array.ep03_classdesign.ep02_coffee;

public class MainCoffee {

	public static void main(String[] args) {

		// Object
//		Coffee coffee1 = new Coffee("아메리카노", 4000);
//		coffee1.printInfo();
//
//		Coffee coffee2 = new Coffee("카푸치노", 5000);
//		coffee2.printInfo();

//		 Array
		 Coffee[] order; // 배열 선언
		
		 order = new Coffee[2]; // 배열 생성
		 order[0] = new Coffee("아메리카노", 4000);
		 order[1] = new Coffee("카페라떼", 5000);
		
		 int total = 0;
		 System.out.println("********** [영수증] **********");
		 for (int i = 0; i < order.length; i++) {
			 order[i].printInfo();
			 
			 int price = order[i].getPrice();
			 total = total + price;
		 }
		 System.out.println("--------------------");
		 System.out.println("총액 = " + total);

	}

}
