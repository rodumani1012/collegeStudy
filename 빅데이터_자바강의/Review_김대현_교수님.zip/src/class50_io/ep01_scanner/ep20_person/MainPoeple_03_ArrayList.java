package class50_io.ep01_scanner.ep20_person;

import java.util.ArrayList;
import java.util.Scanner;


public class MainPoeple_03_ArrayList {

	public static void main(String[] args) {

		// List
		ArrayList<Person> personList = new ArrayList<Person>();

		// Scanner 시작
		Scanner sc = new Scanner(System.in);
		boolean whileLoop = true;
		while (whileLoop) {
			System.out.println("\n[메뉴 선택] ----------------------------");			
			System.out.println("1. 등록");
			System.out.println("2. 전체 출력");
			System.out.println("9. 종료");
			System.out.print("메뉴를 선택하세요 => ");
			int menu = sc.nextInt();

			switch (menu) {			
			case 1:
				System.out.println("\n[등록]");
				System.out.print("이름을 입력하세요 => ");
				String inputName = sc.next();
				System.out.print("나이를 입력하세요 =>");
				int inputAge = sc.nextInt();
				Person p1 = new Person(inputName, inputAge);
				personList.add(p1);
				System.out.println("계속 진행 합니다. ");
				break;
			case 2:
				System.out.println("\n[전체 출력]");
				for (int i = 0; i < personList.size(); i++) {
					Person p2 = personList.get(i);
//					System.out.print((i + 1) + ".");
					p2.printInfo();
				}
				System.out.println("계속 진행 합니다. ");
				break;
			case 9:
				System.out.println("\n[종료]");
				System.out.println("프로그램을 종료합니다.");
				whileLoop = false;	// while() 종료 조건
				break;
			default:
				System.out.println("\n잘못 선택하셨습니다. ");
				System.out.println("계속 진행 합니다. ");
				break;
			}
		}

		// Scanner 종료
		sc.close();
		System.out.println("Scanner Closed.");
	}

}
