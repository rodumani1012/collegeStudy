package class50_io.ep01_scanner.ep20_person;

import java.util.Scanner;

public class MainPoeple_01_Begin {

	public static void main(String[] args) {

		// Scanner 시작
		Scanner sc = new Scanner(System.in);
		boolean whileLoop = true;
		while (whileLoop) {
			System.out.println("\n[메뉴 선택] ----------------------------");
			System.out.println("1. 등록");
			System.out.println("9. 종료");
			System.out.print("메뉴를 선택하세요 => ");
			int menu = sc.nextInt();

			switch (menu) {
			case 1:
				System.out.println("\n[등록]");
				System.out.println("계속 진행 합니다. ");
				break;
			case 9:
				System.out.println("\n[종료]");
				System.out.println("프로그램을 종료합니다.");
				whileLoop = false;	// while() 종료 조건
				break;
			default:
				System.out.println("\n잘못 선택하셨습니다. ");
				System.out.println("계속 진행 합니다. ");
				break;
			}
		}

		// Scanner 종료
		sc.close();
		System.out.println("Scanner Closed.");
	}

}
