package class50_io.ep01_scanner.ep10_calculator;

import java.util.Scanner;

public class MainCalculator_02_Operation {

	public static void main(String[] args) {

		boolean whileLoop = true; // while() 반복 조건
		Scanner sc = new Scanner(System.in); // Scanner 생성

		while (whileLoop) {

			System.out.println("\n[메뉴]-------------------------------");
			System.out.println("1. 더하기");
			System.out.println("2. 빼기");
			System.out.println("3. 곱하기");
			System.out.println("4. 나누기");
			System.out.println("5. 나머지");
			System.out.println("9. 종료");
			
			System.out.print("메뉴를 선택하세요 : ");
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
				System.out.println("\n더하기를 선택하셨습니다.");
				System.out.print("첫번째 정수를 입력하세요 : ");
				int case1First = sc.nextInt();
				System.out.print("두번째 정수를 입력하세요 : ");
				int case1Second = sc.nextInt();
				System.out.println(case1First + " + " + case1Second + " = " + (case1First +case1Second));
				break;
			case 2:
				System.out.println("\n빼기를 선택하셨습니다.");
				System.out.print("첫번째 정수를 입력하세요 : ");
				int case2First = sc.nextInt();
				System.out.print("두번째 정수를 입력하세요 : ");
				int case2Second = sc.nextInt();
				System.out.println(case2First + " - " + case2Second + " = " + (case2First - case2Second));
				break;
			case 3:
				System.out.println("\n곱하기를 선택하셨습니다.");
				System.out.print("첫번째 정수를 입력하세요 : ");
				int case3First = sc.nextInt();
				System.out.print("두번째 정수를 입력하세요 : ");
				int case3Second = sc.nextInt();
				System.out.println(case3First + " * " + case3Second + " = " + (case3First * case3Second));
				break;
			case 4:
				System.out.println("\n나누기를 선택하셨습니다.");
				System.out.print("첫번째 정수를 입력하세요 : ");
				int case4First = sc.nextInt();
				System.out.print("두번째 정수를 입력하세요 : ");
				int case4Second = sc.nextInt();
				System.out.println(case4First + " / " + case4Second + " = " + (case4First / case4Second));
				break;
			case 5:
				System.out.println("\n나머지를 선택하셨습니다.");
				System.out.print("첫번째 정수를 입력하세요 : ");
				int case5First = sc.nextInt();
				System.out.print("두번째 정수를 입력하세요 : ");
				int case5Second = sc.nextInt();
				System.out.println(case5First + " % " + case5Second + " = " + (case5First % case5Second));
				break;
			case 9:
				System.out.println("\n종료를 선택하셨습니다.");
				whileLoop = false;	// while() 종료 조건
				break; // switch() 종료
			default:
				System.out.println("\n잘못 선택하셨습니다. 다시 시작합니다.");
				break;
			}
			
		}

		// Scanner 종료
		sc.close();
		// System.out.println("\nScanner Closed.");
		System.out.println("\nProgram Closed.");
	}
}