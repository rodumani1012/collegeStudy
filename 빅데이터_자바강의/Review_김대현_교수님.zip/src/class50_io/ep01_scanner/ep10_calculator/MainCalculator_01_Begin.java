package class50_io.ep01_scanner.ep10_calculator;

import java.util.Scanner;

public class MainCalculator_01_Begin {

	public static void main(String[] args) {

		boolean whileLoop = true; // while() 반복 조건
		Scanner sc = new Scanner(System.in); // Scanner 생성

		while (whileLoop) {

			System.out.println("\n[메뉴]-------------------------------");
			System.out.println("1. 더하기");
			System.out.println("2. 빼기");
			System.out.println("3. 곱하기");
			System.out.println("4. 나누기");
			System.out.println("5. 나머지");
			System.out.println("9. 종료");
			
			System.out.print("메뉴를 선택하세요 : ");
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
				System.out.println("\n더하기를 선택하셨습니다.");
				break;
			case 2:
				System.out.println("\n빼기를 선택하셨습니다.");
				break;
			case 3:
				System.out.println("\n곱하기를 선택하셨습니다.");
				break;
			case 4:
				System.out.println("\n나누기를 선택하셨습니다.");
				break;
			case 5:
				System.out.println("\n나머지를 선택하셨습니다.");
				break;
			case 9:
				System.out.println("\n종료를 선택하셨습니다.");
				whileLoop = false;	// while() 종료 조건
				break; // switch() 종료
			default:
				System.out.println("\n잘못 선택하셨습니다. 다시 시작합니다.");
				break;
			}
			
		}

		// Scanner 종료
		sc.close();
		// System.out.println("\nScanner Closed.");
		System.out.println("\nProgram Closed.");
	}
}