package class50_io.ep01_scanner.ep02_while;

import java.util.Scanner;

public class MainWhile01_If {

	public static void main(String[] args) {

		// Scanner 시작
		Scanner sc = new Scanner(System.in);

		while (true) {

			System.out.println("\n0 ~ 9 사이의 숫자를 입력하세요.");
			System.out.println("9는 프로그램 종료입니다.");
			System.out.print("숫자 입력 : ");
			int choice = sc.nextInt();

			if (choice == 9) {
				break; // while()을 종료한다.
			} else {
				System.out.println("계속 진행을 합니다.");
			}

		}

		// Scanner 종료
		sc.close();
		System.out.println("Scanner Closed.");

	}

}
