package class50_io.ep01_scanner.ep02_while;

import java.util.Scanner;

public class MainWhile02_Switch {

	public static void main(String[] args) {

		// Scanner 시작
		Scanner sc = new Scanner(System.in);
		boolean whileLoop = true;

		while (whileLoop) {

			System.out.println("\n0 ~ 9 사이의 숫자를 입력하세요.");
			System.out.println("9는 프로그램 종료입니다.");
			System.out.print("숫자 입력 : ");
			int choice = sc.nextInt();

			switch (choice) {
			case 9:
				System.out.println("종료를 선택하셨습니다.");
				whileLoop = false;
				break; // switch() 종료
			default:
				System.out.println("계속 진행을 합니다.");
				break;
			}

		}

		// Scanner 종료
		sc.close();
		System.out.println("Scanner Closed.");

	}

}
