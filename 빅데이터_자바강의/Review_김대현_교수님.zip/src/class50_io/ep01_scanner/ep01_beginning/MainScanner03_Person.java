package class50_io.ep01_scanner.ep01_beginning;

import java.util.Scanner;

public class MainScanner03_Person {

	public static void main(String[] args) {

		// Scanner 시작
		Scanner sc = new Scanner(System.in);

		System.out.print("이름을 입력하세요 : ");
		String inputName = sc.next();

		System.out.print("나이를 입력하세요 : ");
		int inputAge = sc.nextInt();

		Person p = new Person(inputName, inputAge);
		p.printInfo();

		// Scanner 종료
		sc.close();
		System.out.println("Scanner Closed.");
	}
}
