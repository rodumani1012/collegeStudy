package class50_io.ep01_scanner.ep01_beginning;

import java.util.Scanner;

public class MainScanner01 {

	public static void main(String[] args) {

		// Scanner 시작
		Scanner sc = new Scanner(System.in);
		
		
		System.out.print("정수를 입력하세요 : ");
		int intValue = sc.nextInt(); // 정수 입력. Enter를 입력하면 작업 완료
		System.out.println("입력=[" + intValue + "]");
		
		System.out.print("실수를 입력하세요 : ");
		float floatValue = sc.nextFloat(); // 실수 입력. Enter를 입력하면 작업 완료
		System.out.println("입력=[" + floatValue + "]");

		System.out.print("단어를 입력하세요 : ");
		String stringValue = sc.next(); // 공백을 구분자로 단어 구분. Enter를 입력하면 작업 완료
		System.out.println("입력=[" + stringValue + "]");

		/*
		nextXX() method 이후에 바로 nextLine()을 이용했을 때 Scanner는 오류를 나타낸다.
		nextXX() 실행을 위해 enter를 입력하는 순간, nextLine()에 enter가 입력된다. 
		
		따라서 enter 입력 방지를 위해 
		nextXX() 실행 후, sc.nextLine(); 을 강제로 실행하게 한다.
		*/
		sc.nextLine();	// enter 방지 
		System.out.print("문장을 입력하세요 : ");
		String stringLineValue = sc.nextLine(); // 한라인 전체 입력. Enter를 입력하면 작업 완료
		System.out.println("입력=[" + stringLineValue + "]");		

		
		// Scanner 종료
		sc.close();
		System.out.println("Scanner Closed.");

	}

}
