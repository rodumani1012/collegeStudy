package class50_io.ep01_scanner.ep01_beginning;

import java.util.Scanner;

public class MainScanner02_Operation {

	public static void main(String[] args) {

		// Scanner 시작
		Scanner sc = new Scanner(System.in);

		System.out.print("첫번째 숫자를 입력하세요 : ");
		int intValue1 = sc.nextInt();

		System.out.print("두번째 숫자를 입력하세요 : ");
		int intValue2 = sc.nextInt();

		int plusResult = intValue1 + intValue2;
		System.out.println(intValue1 + " + " + intValue2 + " = " + plusResult);

		// Scanner 종료
		sc.close();
		System.out.println("Scanner Closed.");
	}
}
