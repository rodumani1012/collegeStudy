package class50_io.ep01_scanner.ep01_beginning;

import java.util.Scanner;

public class MainScanner04_Coffee {
	
	public static void main(String[] args) {

		// Scanner 시작
		Scanner sc = new Scanner(System.in);

		System.out.print("커피 이름을 입력하세요 : ");
		String inputName = sc.next();

		System.out.print("가격을 입력하세요 : ");
		int inputPrice = sc.nextInt();

		Coffee c = new Coffee(inputName, inputPrice);
		c.printInfo();

		// Scanner 종료
		sc.close();
		System.out.println("Scanner Closed.");
	}

}
