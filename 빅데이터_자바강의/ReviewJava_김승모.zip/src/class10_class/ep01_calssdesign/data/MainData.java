package class10_class.ep01_calssdesign.data;

public class MainData {
	
	public static void main(String[] args) {
		
		Data d = new Data();
		System.out.println("나이=[" + d.getAge() + "]");
		
	}

}
