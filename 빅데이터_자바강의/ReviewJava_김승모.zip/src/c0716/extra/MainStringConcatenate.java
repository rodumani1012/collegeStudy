package c0716.extra;

public class MainStringConcatenate {

	public static void main(String[] args) {
		int val1 = 1;
		int val2 = 2;
		int val3 = 3;
		String s1 = "A";
		String s2 = "B";
		System.out.println(val1 + val2 + val3 + s1 + s2);
		System.out.println(s1 + s2 + val1 + val2 + val3);

	}

}
