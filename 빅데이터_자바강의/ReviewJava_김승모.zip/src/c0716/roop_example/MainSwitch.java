package c0716.roop_example;

public class MainSwitch {

	public static void main(String[] args) {
		int data = 1;
		switch (data) {
		case 1:
			System.out.println("case 1");
			break;
		case 2:
			System.out.println("case 2");
			break;

		default:
			System.out.println("default");
			break;
		}
	}

}
