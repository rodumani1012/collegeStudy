package c0716.roop_example;

public class MainIf {

	public static void main(String[] args) {
		int age = 19;
		if (age > 19) {
			System.out.println("����");
		} else {
			System.out.println("�̼�����");
		}
	}

}
