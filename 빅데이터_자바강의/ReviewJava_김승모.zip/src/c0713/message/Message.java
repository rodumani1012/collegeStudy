package c0713.message;

public class Message {
	
	public void sayHello() {
		System.out.println("Hello");
	}
	public void sayWorld() {
		System.out.println("World");
	}
	public void sayMessage(String message) {
		System.out.println("message=[" + message + "]" );
	}
}
